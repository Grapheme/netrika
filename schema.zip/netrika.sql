-- phpMyAdmin SQL Dump
-- version 4.2.5
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Сен 18 2014 г., 18:18
-- Версия сервера: 5.5.25
-- Версия PHP: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `netrika`
--

-- --------------------------------------------------------

--
-- Структура таблицы `actions`
--

DROP TABLE IF EXISTS `actions`;
CREATE TABLE IF NOT EXISTS `actions` (
`id` int(10) unsigned NOT NULL,
  `group_id` int(10) unsigned DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `action` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `status` int(10) unsigned NOT NULL DEFAULT '0'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=46 ;

--
-- Дамп данных таблицы `actions`
--

INSERT INTO `actions` (`id`, `group_id`, `module`, `action`, `status`) VALUES
(24, 3, 'dictionaries', 'dicval_view', 1),
(25, 3, 'dictionaries', 'dicval_create', 1),
(26, 3, 'dictionaries', 'dicval_edit', 1),
(27, 3, 'dictionaries', 'dicval_delete', 1),
(28, 3, 'dictionaries', 'dicval_entity_view', 1),
(29, 3, 'dictionaries', 'hidden', 1),
(30, 3, 'dictionaries', 'import', 1),
(31, 3, 'galleries', 'view', 1),
(32, 3, 'galleries', 'create', 1),
(33, 3, 'galleries', 'edit', 1),
(34, 3, 'galleries', 'delete', 1),
(35, 3, 'logging', 'logging', 1),
(36, 3, 'news', 'view', 1),
(37, 3, 'news', 'create', 1),
(38, 3, 'news', 'edit', 1),
(39, 3, 'news', 'delete', 1),
(40, 3, 'pages', 'view', 1),
(41, 3, 'pages', 'create', 1),
(42, 3, 'pages', 'edit', 1),
(43, 3, 'pages', 'delete', 1),
(44, 3, 'pages', 'settings', 1),
(45, 3, 'seo', 'edit', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary`
--

DROP TABLE IF EXISTS `dictionary`;
CREATE TABLE IF NOT EXISTS `dictionary` (
`id` int(10) unsigned NOT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `entity` tinyint(1) unsigned DEFAULT NULL,
  `icon_class` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `hide_slug` tinyint(1) unsigned DEFAULT NULL,
  `make_slug_from_name` tinyint(1) unsigned DEFAULT NULL,
  `name_title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `pagination` int(10) unsigned NOT NULL DEFAULT '0',
  `view_access` smallint(5) unsigned DEFAULT NULL,
  `sort_by` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `sort_order_reverse` smallint(5) unsigned NOT NULL DEFAULT '0',
  `sortable` smallint(5) unsigned NOT NULL DEFAULT '1',
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- Дамп данных таблицы `dictionary`
--

INSERT INTO `dictionary` (`id`, `slug`, `name`, `entity`, `icon_class`, `hide_slug`, `make_slug_from_name`, `name_title`, `pagination`, `view_access`, `sort_by`, `sort_order_reverse`, `sortable`, `order`, `created_at`, `updated_at`) VALUES
(1, 'solutions', 'Решения', 1, 'fa-thumb-tack', 1, 1, 'Название решения', 0, 2, NULL, 0, 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(2, 'projects', 'Проекты', 1, 'fa-bookmark', 1, 1, 'Название проекта', 0, 2, NULL, 0, 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(3, 'clients', 'Клиенты', 1, 'fa-android', 1, 1, 'Наименование клиента', 0, 2, NULL, 0, 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(4, 'companies', 'Компании', 1, 'fa-apple', 1, 1, 'Наименование компании', 0, 2, NULL, 0, 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(5, 'vacancies', 'Вакансии', 1, 'fa-user-md', 1, 1, 'Название вакансии', 0, 2, NULL, 0, 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(6, 'entities-tags', 'Теги', 1, 'fa-tags', 1, 1, 'Название тега', 0, 1, NULL, 0, 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(7, 'solution-documents', 'Норматив. документы (Решения)', 0, 'fa-file-text', 1, 1, 'Название документа', 0, 2, NULL, 0, 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(8, 'project-documents', 'Норматив. документы (Проекты)', 0, 'fa-file-text', 1, 1, 'Название документа', 0, 2, NULL, 0, 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(9, 'clients-institutions', 'Учреждения', 0, 'fa-building', 1, 1, 'Название учреждения', 0, 2, NULL, 0, 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(10, 'actions-types', 'Типы событий', 1, 'fa-bolt', 1, 1, 'Название типа события', 0, 1, NULL, 0, 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(11, 'actions-history', 'История событий', 1, 'fa-bell', 1, 1, NULL, 30, 1, 'created_at', 1, 0, 0, '2014-09-18 06:22:57', '2014-09-18 09:55:55');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_fields_values`
--

DROP TABLE IF EXISTS `dictionary_fields_values`;
CREATE TABLE IF NOT EXISTS `dictionary_fields_values` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=217 ;

--
-- Дамп данных таблицы `dictionary_fields_values`
--

INSERT INTO `dictionary_fields_values` (`id`, `dicval_id`, `language`, `key`, `value`, `created_at`, `updated_at`) VALUES
(25, 27, NULL, 'description_target_audience', '', '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(26, 27, NULL, 'describes_purpose_decision', '', '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(27, 27, NULL, 'description_advantages_solution', '', '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(28, 27, NULL, 'image_schemes_work', '', '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(29, 27, NULL, 'identify_features_solution', '', '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(30, 27, NULL, 'description_integration', '', '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(31, 27, NULL, 'description_plans', '', '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(32, 27, NULL, 'description_components', '', '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(33, 27, NULL, 'description_partners', '', '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(34, 27, NULL, 'availability_demonstrate', NULL, '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(35, 27, NULL, 'link_to_file_presentation', NULL, '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(36, 27, NULL, 'tags_id', '0', '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(37, 28, NULL, 'user_id', '3', '2014-09-18 07:58:59', '2014-09-18 07:58:59'),
(38, 28, NULL, 'action_id', '1', '2014-09-18 07:58:59', '2014-09-18 07:58:59'),
(39, 28, NULL, 'title', 'Здравоохранение', '2014-09-18 07:58:59', '2014-09-18 07:58:59'),
(40, 28, NULL, 'link', NULL, '2014-09-18 07:58:59', '2014-09-18 07:58:59'),
(41, 28, NULL, 'created_time', '2014-09-18 11:58:58', '2014-09-18 07:58:59', '2014-09-18 07:58:59'),
(42, 29, NULL, 'description_target_audience', '', '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(43, 29, NULL, 'describes_purpose_decision', '', '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(44, 29, NULL, 'description_advantages_solution', '', '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(45, 29, NULL, 'image_schemes_work', '', '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(46, 29, NULL, 'identify_features_solution', '', '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(47, 29, NULL, 'description_integration', '', '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(48, 29, NULL, 'description_plans', '', '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(49, 29, NULL, 'description_components', '', '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(50, 29, NULL, 'description_partners', '', '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(51, 29, NULL, 'availability_demonstrate', NULL, '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(52, 29, NULL, 'link_to_file_presentation', NULL, '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(53, 29, NULL, 'tags_id', '0', '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(54, 30, NULL, 'description_target_audience', '', '2014-09-18 08:00:14', '2014-09-18 08:00:14'),
(55, 30, NULL, 'describes_purpose_decision', '', '2014-09-18 08:00:14', '2014-09-18 08:00:14'),
(56, 30, NULL, 'description_advantages_solution', '', '2014-09-18 08:00:14', '2014-09-18 08:00:14'),
(57, 30, NULL, 'image_schemes_work', '', '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(58, 30, NULL, 'identify_features_solution', '', '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(59, 30, NULL, 'description_integration', '', '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(60, 30, NULL, 'description_plans', '', '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(61, 30, NULL, 'description_components', '', '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(62, 30, NULL, 'description_partners', '', '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(63, 30, NULL, 'availability_demonstrate', NULL, '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(64, 30, NULL, 'link_to_file_presentation', NULL, '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(65, 30, NULL, 'tags_id', '0', '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(66, 31, NULL, 'user_id', '3', '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(67, 31, NULL, 'action_id', '1', '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(68, 31, NULL, 'title', '12315', '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(69, 31, NULL, 'link', NULL, '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(70, 31, NULL, 'created_time', '2014-09-18 12:00:15', '2014-09-18 08:00:15', '2014-09-18 08:00:15'),
(71, 32, NULL, 'description_target_audience', '', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(72, 32, NULL, 'describes_purpose_decision', '', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(73, 32, NULL, 'description_advantages_solution', '', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(74, 32, NULL, 'image_schemes_work', '', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(75, 32, NULL, 'identify_features_solution', '', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(76, 32, NULL, 'description_integration', '', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(77, 32, NULL, 'description_plans', '', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(78, 32, NULL, 'description_components', '', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(79, 32, NULL, 'description_partners', '', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(80, 32, NULL, 'availability_demonstrate', NULL, '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(81, 32, NULL, 'link_to_file_presentation', NULL, '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(82, 32, NULL, 'tags_id', '0', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(83, 33, NULL, 'user_id', '3', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(84, 33, NULL, 'action_id', '1', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(85, 33, NULL, 'title', '18615', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(86, 33, NULL, 'link', NULL, '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(87, 33, NULL, 'created_time', '2014-09-18 12:01:45', '2014-09-18 08:01:45', '2014-09-18 08:01:45'),
(100, 35, NULL, 'description_target_audience', '', '2014-09-18 08:07:58', '2014-09-18 08:07:58'),
(101, 35, NULL, 'describes_purpose_decision', '', '2014-09-18 08:07:58', '2014-09-18 08:07:58'),
(102, 35, NULL, 'description_advantages_solution', '', '2014-09-18 08:07:58', '2014-09-18 08:07:58'),
(103, 35, NULL, 'image_schemes_work', '', '2014-09-18 08:07:58', '2014-09-18 08:07:58'),
(104, 35, NULL, 'identify_features_solution', '', '2014-09-18 08:07:58', '2014-09-18 08:07:58'),
(105, 35, NULL, 'description_integration', '', '2014-09-18 08:07:58', '2014-09-18 08:07:58'),
(106, 35, NULL, 'description_plans', '', '2014-09-18 08:07:58', '2014-09-18 08:07:58'),
(107, 35, NULL, 'description_components', '', '2014-09-18 08:07:59', '2014-09-18 08:07:59'),
(108, 35, NULL, 'description_partners', '', '2014-09-18 08:07:59', '2014-09-18 08:07:59'),
(109, 35, NULL, 'availability_demonstrate', NULL, '2014-09-18 08:07:59', '2014-09-18 08:07:59'),
(110, 35, NULL, 'link_to_file_presentation', NULL, '2014-09-18 08:07:59', '2014-09-18 08:07:59'),
(111, 35, NULL, 'tags_id', '0', '2014-09-18 08:07:59', '2014-09-18 08:07:59'),
(112, 36, NULL, 'description_target_audience', '', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(113, 36, NULL, 'describes_purpose_decision', '', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(114, 36, NULL, 'description_advantages_solution', '', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(115, 36, NULL, 'image_schemes_work', '', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(116, 36, NULL, 'identify_features_solution', '', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(117, 36, NULL, 'description_integration', '', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(118, 36, NULL, 'description_plans', '', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(119, 36, NULL, 'description_components', '', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(120, 36, NULL, 'description_partners', '', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(121, 36, NULL, 'availability_demonstrate', NULL, '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(122, 36, NULL, 'link_to_file_presentation', NULL, '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(123, 36, NULL, 'tags_id', '0', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(124, 37, NULL, 'user_id', '3', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(125, 37, NULL, 'action_id', '1', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(126, 37, NULL, 'title', 'sdfsdfsd', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(127, 37, NULL, 'link', NULL, '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(128, 37, NULL, 'created_time', '2014-09-18 12:08:12', '2014-09-18 08:08:12', '2014-09-18 08:08:12'),
(129, 38, NULL, 'description_target_audience', '', '2014-09-18 08:08:56', '2014-09-18 08:08:56'),
(130, 38, NULL, 'describes_purpose_decision', '', '2014-09-18 08:08:56', '2014-09-18 08:08:56'),
(131, 38, NULL, 'description_advantages_solution', '', '2014-09-18 08:08:56', '2014-09-18 08:08:56'),
(132, 38, NULL, 'image_schemes_work', '', '2014-09-18 08:08:56', '2014-09-18 08:08:56'),
(133, 38, NULL, 'identify_features_solution', '', '2014-09-18 08:08:56', '2014-09-18 08:08:56'),
(134, 38, NULL, 'description_integration', '', '2014-09-18 08:08:56', '2014-09-18 08:08:56'),
(135, 38, NULL, 'description_plans', '', '2014-09-18 08:08:56', '2014-09-18 08:08:56'),
(136, 38, NULL, 'description_components', '', '2014-09-18 08:08:56', '2014-09-18 08:08:56'),
(137, 38, NULL, 'description_partners', '', '2014-09-18 08:08:56', '2014-09-18 08:08:56'),
(138, 38, NULL, 'availability_demonstrate', NULL, '2014-09-18 08:08:56', '2014-09-18 08:08:56'),
(139, 38, NULL, 'link_to_file_presentation', NULL, '2014-09-18 08:08:56', '2014-09-18 08:08:56'),
(140, 38, NULL, 'tags_id', '0', '2014-09-18 08:08:57', '2014-09-18 08:08:57'),
(141, 39, NULL, 'user_id', '3', '2014-09-18 08:08:57', '2014-09-18 08:08:57'),
(142, 39, NULL, 'action_id', '1', '2014-09-18 08:08:57', '2014-09-18 08:08:57'),
(143, 39, NULL, 'title', 'вован', '2014-09-18 08:08:57', '2014-09-18 08:08:57'),
(144, 39, NULL, 'link', NULL, '2014-09-18 08:08:57', '2014-09-18 08:08:57'),
(145, 39, NULL, 'created_time', '2014-09-18 12:08:57', '2014-09-18 08:08:57', '2014-09-18 08:08:57'),
(146, 40, NULL, 'description_target_audience', '', '2014-09-18 08:09:45', '2014-09-18 08:09:45'),
(147, 40, NULL, 'describes_purpose_decision', '', '2014-09-18 08:09:45', '2014-09-18 08:09:45'),
(148, 40, NULL, 'description_advantages_solution', '', '2014-09-18 08:09:45', '2014-09-18 08:09:45'),
(149, 40, NULL, 'image_schemes_work', '', '2014-09-18 08:09:45', '2014-09-18 08:09:45'),
(150, 40, NULL, 'identify_features_solution', '', '2014-09-18 08:09:45', '2014-09-18 08:09:45'),
(151, 40, NULL, 'description_integration', '', '2014-09-18 08:09:45', '2014-09-18 08:09:45'),
(152, 40, NULL, 'description_plans', '', '2014-09-18 08:09:45', '2014-09-18 08:09:45'),
(153, 40, NULL, 'description_components', '', '2014-09-18 08:09:45', '2014-09-18 08:09:45'),
(154, 40, NULL, 'description_partners', '', '2014-09-18 08:09:45', '2014-09-18 08:09:45'),
(155, 40, NULL, 'availability_demonstrate', NULL, '2014-09-18 08:09:45', '2014-09-18 08:09:45'),
(156, 40, NULL, 'link_to_file_presentation', NULL, '2014-09-18 08:09:45', '2014-09-18 08:09:45'),
(157, 40, NULL, 'tags_id', '0', '2014-09-18 08:09:45', '2014-09-18 08:09:45'),
(158, 41, NULL, 'description_target_audience', '', '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(159, 41, NULL, 'describes_purpose_decision', '', '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(160, 41, NULL, 'description_advantages_solution', '', '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(161, 41, NULL, 'image_schemes_work', '', '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(162, 41, NULL, 'identify_features_solution', '', '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(163, 41, NULL, 'description_integration', '', '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(164, 41, NULL, 'description_plans', '', '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(165, 41, NULL, 'description_components', '', '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(166, 41, NULL, 'description_partners', '', '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(167, 41, NULL, 'availability_demonstrate', NULL, '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(168, 41, NULL, 'link_to_file_presentation', NULL, '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(169, 41, NULL, 'tags_id', '0', '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(170, 42, NULL, 'description_target_audience', '', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(171, 42, NULL, 'describes_purpose_decision', '', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(172, 42, NULL, 'description_advantages_solution', '', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(173, 42, NULL, 'image_schemes_work', '', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(174, 42, NULL, 'identify_features_solution', '', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(175, 42, NULL, 'description_integration', '', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(176, 42, NULL, 'description_plans', '', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(177, 42, NULL, 'description_components', '', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(178, 42, NULL, 'description_partners', '', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(179, 42, NULL, 'availability_demonstrate', NULL, '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(180, 42, NULL, 'link_to_file_presentation', NULL, '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(181, 42, NULL, 'tags_id', '0', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(182, 43, NULL, 'user_id', '3', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(183, 43, NULL, 'action_id', '1', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(184, 43, NULL, 'title', 'dfdf', '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(185, 43, NULL, 'link', NULL, '2014-09-18 08:11:10', '2014-09-18 08:11:10'),
(186, 43, NULL, 'created_time', '2014-09-18 12:11:09', '2014-09-18 08:11:10', '2014-09-18 08:11:10'),
(187, 44, NULL, 'user_id', '3', '2014-09-18 09:36:54', '2014-09-18 09:36:54'),
(188, 44, NULL, 'action_id', '2', '2014-09-18 09:36:54', '2014-09-18 09:36:54'),
(189, 44, NULL, 'title', '121212112', '2014-09-18 09:36:54', '2014-09-18 09:36:54'),
(190, 44, NULL, 'link', NULL, '2014-09-18 09:36:54', '2014-09-18 09:36:54'),
(191, 44, NULL, 'created_time', '2014-09-18 13:36:54', '2014-09-18 09:36:54', '2014-09-18 09:36:54'),
(192, 45, NULL, 'user_id', '3', '2014-09-18 09:37:12', '2014-09-18 09:37:12'),
(193, 45, NULL, 'action_id', '3', '2014-09-18 09:37:12', '2014-09-18 09:37:12'),
(194, 45, NULL, 'title', '121212112', '2014-09-18 09:37:12', '2014-09-18 09:37:12'),
(195, 45, NULL, 'link', NULL, '2014-09-18 09:37:12', '2014-09-18 09:37:12'),
(196, 45, NULL, 'created_time', '2014-09-18 13:37:12', '2014-09-18 09:37:12', '2014-09-18 09:37:12'),
(200, 47, NULL, 'user_id', '3', '2014-09-18 09:37:34', '2014-09-18 09:37:34'),
(201, 47, NULL, 'action_id', '4', '2014-09-18 09:37:34', '2014-09-18 09:37:34'),
(202, 47, NULL, 'title', '2312321312312', '2014-09-18 09:37:34', '2014-09-18 09:37:34'),
(203, 47, NULL, 'link', NULL, '2014-09-18 09:37:34', '2014-09-18 09:37:34'),
(204, 47, NULL, 'created_time', '2014-09-18 13:37:34', '2014-09-18 09:37:34', '2014-09-18 09:37:34'),
(205, 48, NULL, 'user_id', '3', '2014-09-18 09:37:46', '2014-09-18 09:37:46'),
(206, 48, NULL, 'action_id', '6', '2014-09-18 09:37:46', '2014-09-18 09:37:46'),
(207, 48, NULL, 'title', '2312321312312', '2014-09-18 09:37:46', '2014-09-18 09:37:46'),
(208, 48, NULL, 'link', NULL, '2014-09-18 09:37:46', '2014-09-18 09:37:46'),
(209, 48, NULL, 'created_time', '2014-09-18 13:37:46', '2014-09-18 09:37:46', '2014-09-18 09:37:46'),
(210, 49, NULL, 'description_vacancy', '', '2014-09-18 09:38:01', '2014-09-18 09:38:01'),
(211, 49, NULL, 'link_to_vacancy', '', '2014-09-18 09:38:01', '2014-09-18 09:38:01'),
(212, 50, NULL, 'user_id', '3', '2014-09-18 09:38:01', '2014-09-18 09:38:01'),
(213, 50, NULL, 'action_id', '22', '2014-09-18 09:38:01', '2014-09-18 09:38:01'),
(214, 50, NULL, 'title', '332123', '2014-09-18 09:38:01', '2014-09-18 09:38:01'),
(215, 50, NULL, 'link', NULL, '2014-09-18 09:38:01', '2014-09-18 09:38:01'),
(216, 50, NULL, 'created_time', '2014-09-18 13:38:01', '2014-09-18 09:38:01', '2014-09-18 09:38:01');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values`
--

DROP TABLE IF EXISTS `dictionary_values`;
CREATE TABLE IF NOT EXISTS `dictionary_values` (
`id` int(10) unsigned NOT NULL,
  `dic_id` int(10) unsigned DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=51 ;

--
-- Дамп данных таблицы `dictionary_values`
--

INSERT INTO `dictionary_values` (`id`, `dic_id`, `slug`, `name`, `order`, `created_at`, `updated_at`) VALUES
(1, 10, 'dobavleno-reshenie', 'Добавлено решение', 1, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(2, 10, 'otredaktirovano-reshenie', 'Отредактировано решение', 2, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(3, 10, 'udaleno-reshenie', 'Удалено решение', 3, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(4, 10, 'reshenie-sozdan-normativnyy-dokument', 'Решение. Создан нормативный документ', 4, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(5, 10, 'reshenie-otredaktirovan-normativnyy-dokument', 'Решение. Отредактирован нормативный документ', 5, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(6, 10, 'reshenie-udalen-normativnyy-dokument', 'Решение. Удален нормативный документ', 6, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(7, 10, 'dobavlen-proekt', 'Добавлен проект', 7, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(8, 10, 'otredaktirovan-proekt', 'Отредактирован проект', 8, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(9, 10, 'udalen-proekt', 'Удален проект', 9, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(10, 10, 'proekt-sozdan-normativnyy-dokument', 'Проект. Создан нормативный документ', 10, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(11, 10, 'proekt-otredaktirovan-normativnyy-dokument', 'Проект. Отредактирован нормативный документ', 11, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(12, 10, 'proekt-udalen-normativnyy-dokument', 'Проект. Удален нормативный документ', 12, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(13, 10, 'dobavlen-klient', 'Добавлен клиент', 13, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(14, 10, 'otredaktirovan-klient', 'Отредактирован клиент', 14, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(15, 10, 'udalen-klient', 'Удален клиент', 15, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(16, 10, 'klient-sozdano-uchrejdenie', 'Клиент. Создано учреждение', 16, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(17, 10, 'klient-otredaktirovano-uchrejdenie', 'Клиент. Отредактировано учреждение', 17, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(18, 10, 'klient-udaleno-uchrejdenie', 'Клиент. Удалено учреждение', 18, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(19, 10, 'dobavlena-kompaniya', 'Добавлена компания', 19, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(20, 10, 'otredaktirovana-kompaniya', 'Отредактирована компания', 20, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(21, 10, 'udalena-kompaniya', 'Удалена компания', 21, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(22, 10, 'dobavlena-vakansiya', 'Добавлена вакансия', 22, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(23, 10, 'otredaktirovana-vakansiya', 'Отредактирована вакансия', 23, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(24, 10, 'udalena-vakansiya', 'Удалена вакансия', 24, '2014-09-18 06:22:58', '2014-09-18 06:22:58'),
(27, 1, 'zdravoohranenie', 'Здравоохранение', NULL, '2014-09-18 07:58:58', '2014-09-18 07:58:58'),
(28, 11, 'dobavleno-reshenie.2014-09-18 11:58:58', 'Здравоохранение', 5, '2014-09-18 07:58:58', '2014-09-18 08:13:06'),
(29, 1, 'zdravoohranenie', 'Здравоохранение', NULL, '2014-09-18 07:59:34', '2014-09-18 07:59:34'),
(30, 1, '12315', '12315', NULL, '2014-09-18 08:00:14', '2014-09-18 08:00:14'),
(31, 11, 'dobavleno-reshenie.2014-09-18 12:00:15', '12315', 0, '2014-09-18 08:00:15', '2014-09-18 08:13:06'),
(32, 1, '18615', '18615', NULL, '2014-09-18 08:01:44', '2014-09-18 08:01:45'),
(33, 11, 'dobavleno-reshenie.2014-09-18 12:01:45', '18615', 1, '2014-09-18 08:01:45', '2014-09-18 08:13:06'),
(35, 1, 'asdsadas', 'asdsadas', NULL, '2014-09-18 08:07:58', '2014-09-18 08:07:58'),
(36, 1, 'sdfsdfsd', 'sdfsdfsd', NULL, '2014-09-18 08:08:11', '2014-09-18 08:08:12'),
(37, 11, 'dobavleno-reshenie.2014-09-18 12:08:12', 'sdfsdfsd', 3, '2014-09-18 08:08:12', '2014-09-18 08:13:06'),
(38, 1, 'vovan', 'вован', NULL, '2014-09-18 08:08:56', '2014-09-18 08:08:56'),
(39, 11, 'dobavleno-reshenie.2014-09-18 12:08:57', 'вован', 4, '2014-09-18 08:08:57', '2014-09-18 08:13:06'),
(40, 1, 'vovan', 'вован', NULL, '2014-09-18 08:09:44', '2014-09-18 08:09:44'),
(41, 1, 'asdsada', 'asdsada', NULL, '2014-09-18 08:10:08', '2014-09-18 08:10:08'),
(42, 1, 'dfdf', 'dfdf', NULL, '2014-09-18 08:11:09', '2014-09-18 08:11:09'),
(43, 11, 'dobavleno-reshenie.2014-09-18 12:11:09', 'dfdf', 2, '2014-09-18 08:11:09', '2014-09-18 08:13:06'),
(44, 11, 'otredaktirovano-reshenie.2014-09-18 13:36:54', '121212112', NULL, '2014-09-18 09:36:54', '2014-09-18 09:36:54'),
(45, 11, 'udaleno-reshenie.2014-09-18 13:37:12', '121212112', NULL, '2014-09-18 09:37:12', '2014-09-18 09:37:12'),
(47, 11, 'reshenie-sozdan-normativnyy-dokument.2014-09-18 13:37:34', '2312321312312', NULL, '2014-09-18 09:37:34', '2014-09-18 09:37:34'),
(48, 11, 'reshenie-udalen-normativnyy-dokument.2014-09-18 13:37:46', '2312321312312', NULL, '2014-09-18 09:37:46', '2014-09-18 09:37:46'),
(49, 5, '332123', '332123', NULL, '2014-09-18 09:38:00', '2014-09-18 09:38:00'),
(50, 11, 'dobavlena-vakansiya.2014-09-18 13:38:01', '332123', NULL, '2014-09-18 09:38:01', '2014-09-18 09:38:01');

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_meta`
--

DROP TABLE IF EXISTS `dictionary_values_meta`;
CREATE TABLE IF NOT EXISTS `dictionary_values_meta` (
`id` int(10) unsigned NOT NULL,
  `dicval_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `dictionary_values_rel`
--

DROP TABLE IF EXISTS `dictionary_values_rel`;
CREATE TABLE IF NOT EXISTS `dictionary_values_rel` (
  `dicval_parent_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_id` int(10) unsigned NOT NULL DEFAULT '0',
  `dicval_child_dic` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `galleries`
--

DROP TABLE IF EXISTS `galleries`;
CREATE TABLE IF NOT EXISTS `galleries` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `settings` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `groups`
--

DROP TABLE IF EXISTS `groups`;
CREATE TABLE IF NOT EXISTS `groups` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `desc` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `dashboard` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `start_url` varchar(256) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `groups`
--

INSERT INTO `groups` (`id`, `name`, `desc`, `dashboard`, `start_url`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'Администраторы', 'admin', '', '2014-09-18 06:22:56', '2014-09-18 06:22:56'),
(2, 'user', 'Пользователи', '', '', '2014-09-18 06:22:56', '2014-09-18 06:22:56'),
(3, 'moderator', 'Модераторы', 'admin', '', '2014-09-18 06:22:56', '2014-09-18 10:00:06');

-- --------------------------------------------------------

--
-- Структура таблицы `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `migration` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `migrations`
--

INSERT INTO `migrations` (`migration`, `batch`) VALUES
('2014_01_01_100000_create_groups_table', 1),
('2014_01_01_100010_create_users_table', 1),
('2014_01_01_100020_create_modules_table', 1),
('2014_01_01_100030_create_actions_table', 1),
('2014_01_01_100040_create_session_table', 1),
('2014_01_01_100050_create_settings_table', 1),
('2014_01_01_100051_create_storages_table', 1),
('2014_01_01_100060_create_pages_tables', 1),
('2014_01_01_100070_create_news_tables', 1),
('2014_01_01_100080_create_galleries_table', 1),
('2014_01_01_100090_create_photos_table', 1),
('2014_01_01_100100_create_rel_mod_gallery_table', 1),
('2014_01_01_100110_create_seo_table', 1),
('2014_07_03_161130_create_dics_tables', 1),
('2014_09_02_161130_create_uploads_tables', 1),
('2014_09_02_161140_create_video_tables', 1);

-- --------------------------------------------------------

--
-- Структура таблицы `modules`
--

DROP TABLE IF EXISTS `modules`;
CREATE TABLE IF NOT EXISTS `modules` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `on` tinyint(1) NOT NULL DEFAULT '0',
  `order` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Дамп данных таблицы `modules`
--

INSERT INTO `modules` (`id`, `name`, `on`, `order`, `created_at`, `updated_at`) VALUES
(1, 'system', 1, 0, '2014-09-18 06:22:57', '2014-09-18 07:03:38'),
(2, 'pages', 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(3, 'news', 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(4, 'galleries', 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(5, 'seo', 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(6, 'dictionaries', 1, 0, '2014-09-18 06:22:57', '2014-09-18 06:22:57'),
(7, 'logging', 1, 0, '2014-09-18 07:03:20', '2014-09-18 09:49:50');

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

DROP TABLE IF EXISTS `news`;
CREATE TABLE IF NOT EXISTS `news` (
`id` int(10) unsigned NOT NULL,
  `slug` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `published_at` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `news_meta`
--

DROP TABLE IF EXISTS `news_meta`;
CREATE TABLE IF NOT EXISTS `news_meta` (
`id` int(10) unsigned NOT NULL,
  `news_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `preview` text COLLATE utf8_unicode_ci,
  `content` mediumtext COLLATE utf8_unicode_ci,
  `photo_id` int(10) unsigned DEFAULT NULL,
  `gallery_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages`
--

DROP TABLE IF EXISTS `pages`;
CREATE TABLE IF NOT EXISTS `pages` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `type_id` int(10) unsigned DEFAULT NULL,
  `publication` tinyint(1) unsigned DEFAULT '1',
  `start_page` tinyint(1) unsigned DEFAULT NULL,
  `in_menu` tinyint(1) unsigned DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks`
--

DROP TABLE IF EXISTS `pages_blocks`;
CREATE TABLE IF NOT EXISTS `pages_blocks` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `slug` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `desc` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `order` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages_blocks_meta`
--

DROP TABLE IF EXISTS `pages_blocks_meta`;
CREATE TABLE IF NOT EXISTS `pages_blocks_meta` (
`id` int(10) unsigned NOT NULL,
  `block_id` int(10) unsigned DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `content` text COLLATE utf8_unicode_ci,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `pages_meta`
--

DROP TABLE IF EXISTS `pages_meta`;
CREATE TABLE IF NOT EXISTS `pages_meta` (
`id` int(10) unsigned NOT NULL,
  `page_id` int(10) unsigned DEFAULT NULL,
  `language` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `template` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gallery_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `rel_mod_gallery`
--

DROP TABLE IF EXISTS `rel_mod_gallery`;
CREATE TABLE IF NOT EXISTS `rel_mod_gallery` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(16) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT '0',
  `gallery_id` int(10) unsigned DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `seo`
--

DROP TABLE IF EXISTS `seo`;
CREATE TABLE IF NOT EXISTS `seo` (
`id` int(10) unsigned NOT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `title` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `keywords` text COLLATE utf8_unicode_ci,
  `url` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `h1` varchar(256) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `payload` text COLLATE utf8_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `payload`, `last_activity`) VALUES
('4b508c8be88612aff0d890bafb9dbcdfe90ad658', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiQm85RUxKR3VYNEpSMjlBZFZiTTNUQ2hwYjI2c256WGlsdVc4aFdIaCI7czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7aTozO3M6MjI6IlBIUERFQlVHQkFSX1NUQUNLX0RBVEEiO2E6MDp7fXM6OToiX3NmMl9tZXRhIjthOjM6e3M6MToidSI7aToxNDExMDQ5ODEyO3M6MToiYyI7aToxNDExMDM4NDgyO3M6MToibCI7czoxOiIwIjt9fQ==', 1411049812),
('ae1c62cafbd7a23969daa4c3fa3a0259a88cecb4', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoiSjN5RHdxQVIxYmRoNlJDelFhWXFOQU9PbGFKSkdXcTZIMm8wYXJRTCI7czoyMjoiUEhQREVCVUdCQVJfU1RBQ0tfREFUQSI7YTowOnt9czo1OiJmbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX1zOjM4OiJsb2dpbl84MmU1ZDJjNTZiZGQwODExMzE4ZjBjZjA3OGI3OGJmYyI7aToxO3M6OToiX3NmMl9tZXRhIjthOjM6e3M6MToidSI7aToxNDExMDQ5NzkyO3M6MToiYyI7aToxNDExMDM1NzcyO3M6MToibCI7czoxOiIwIjt9fQ==', 1411049792);

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

DROP TABLE IF EXISTS `settings`;
CREATE TABLE IF NOT EXISTS `settings` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`id`, `name`, `value`, `created_at`, `updated_at`) VALUES
(1, 'language', 'ru', '2014-09-18 06:22:56', '2014-09-18 06:22:56');

-- --------------------------------------------------------

--
-- Структура таблицы `storages`
--

DROP TABLE IF EXISTS `storages`;
CREATE TABLE IF NOT EXISTS `storages` (
`id` int(10) unsigned NOT NULL,
  `name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `value` text COLLATE utf8_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `uploads`
--

DROP TABLE IF EXISTS `uploads`;
CREATE TABLE IF NOT EXISTS `uploads` (
`id` int(10) unsigned NOT NULL,
  `path` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `original_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `filesize` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mimetype` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime1` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mime2` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
`id` int(10) unsigned NOT NULL,
  `group_id` smallint(5) unsigned DEFAULT '0',
  `name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `surname` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `active` smallint(5) unsigned DEFAULT '0',
  `password` varchar(60) COLLATE utf8_unicode_ci DEFAULT NULL,
  `photo` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `thumbnail` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `temporary_code` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  `code_life` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `group_id`, `name`, `surname`, `email`, `active`, `password`, `photo`, `thumbnail`, `temporary_code`, `code_life`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 1, 'Администратор', '', 'admin@netrika.ru', 1, '$2y$10$9A6dsJQGwB/YAIM.T7/Qf.hD8OQuN41r3qsnvqhzty1LWgdNDo9HS', '', '', '', 0, 'JWx0qcfi2vHZU9nGKgVWKr59qAinJl6VGEZWZpXQjNmKRQF5sws8LWvXjUXP', '2014-09-18 06:22:56', '2014-09-18 06:22:57'),
(2, 2, 'Пользователь', '', 'user@netrika.ru', 1, '$2y$10$0cM.70IyOYtAJUXWRbM8yeHuFfIcqWUNFRuZ0brqe5FyN2kjMNwhK', '', '', '', 0, NULL, '2014-09-18 06:22:56', '2014-09-18 06:22:56'),
(3, 3, 'Модератор', '', 'moder@netrika.ru', 1, '$2y$10$5nhVo/6/Kdoc.LQTQ/rcueNq2ypraTrh7nbNXRiYmIm2d315XYZkW', '', '', '', 0, 'iHPYl06DIC1GC9DcU0ifF7DGc3EXIBCjiPV7mx30xHKYqHDdBEaBUKDMJr6k', '2014-09-18 06:22:56', '2014-09-18 07:08:22');

-- --------------------------------------------------------

--
-- Структура таблицы `videos`
--

DROP TABLE IF EXISTS `videos`;
CREATE TABLE IF NOT EXISTS `videos` (
`id` int(10) unsigned NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `embed` text COLLATE utf8_unicode_ci,
  `image_id` int(11) DEFAULT NULL,
  `module` varchar(32) COLLATE utf8_unicode_ci DEFAULT NULL,
  `unit_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `actions`
--
ALTER TABLE `actions`
 ADD PRIMARY KEY (`id`), ADD KEY `actions_group_id_index` (`group_id`), ADD KEY `actions_module_index` (`module`), ADD KEY `actions_action_index` (`action`), ADD KEY `actions_status_index` (`status`);

--
-- Indexes for table `dictionary`
--
ALTER TABLE `dictionary`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `dictionary_slug_unique` (`slug`), ADD KEY `dictionary_name_index` (`name`), ADD KEY `dictionary_entity_index` (`entity`), ADD KEY `dictionary_view_access_index` (`view_access`), ADD KEY `dictionary_order_index` (`order`);

--
-- Indexes for table `dictionary_fields_values`
--
ALTER TABLE `dictionary_fields_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_fields_values_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_fields_values_language_index` (`language`), ADD KEY `dictionary_fields_values_key_index` (`key`);

--
-- Indexes for table `dictionary_values`
--
ALTER TABLE `dictionary_values`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_values_dic_id_index` (`dic_id`), ADD KEY `dictionary_values_slug_index` (`slug`), ADD KEY `dictionary_values_order_index` (`order`);

--
-- Indexes for table `dictionary_values_meta`
--
ALTER TABLE `dictionary_values_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `dictionary_values_meta_dicval_id_index` (`dicval_id`), ADD KEY `dictionary_values_meta_language_index` (`language`);

--
-- Indexes for table `dictionary_values_rel`
--
ALTER TABLE `dictionary_values_rel`
 ADD PRIMARY KEY (`dicval_parent_id`,`dicval_child_id`), ADD KEY `dictionary_values_rel_dicval_parent_id_index` (`dicval_parent_id`), ADD KEY `dictionary_values_rel_dicval_child_id_index` (`dicval_child_id`), ADD KEY `dictionary_values_rel_dicval_child_dic_index` (`dicval_child_dic`(255));

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `groups_name_unique` (`name`);

--
-- Indexes for table `modules`
--
ALTER TABLE `modules`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
 ADD PRIMARY KEY (`id`), ADD KEY `news_type_id_index` (`type_id`), ADD KEY `news_publication_index` (`publication`), ADD KEY `news_published_at_index` (`published_at`);

--
-- Indexes for table `news_meta`
--
ALTER TABLE `news_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `news_meta_news_id_index` (`news_id`), ADD KEY `news_meta_language_index` (`language`);

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_slug_index` (`slug`), ADD KEY `pages_type_id_index` (`type_id`), ADD KEY `pages_publication_index` (`publication`), ADD KEY `pages_start_page_index` (`start_page`), ADD KEY `pages_in_menu_index` (`in_menu`), ADD KEY `pages_order_index` (`order`);

--
-- Indexes for table `pages_blocks`
--
ALTER TABLE `pages_blocks`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_blocks_page_id_index` (`page_id`), ADD KEY `pages_blocks_slug_index` (`slug`), ADD KEY `pages_blocks_order_index` (`order`);

--
-- Indexes for table `pages_blocks_meta`
--
ALTER TABLE `pages_blocks_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_blocks_meta_block_id_index` (`block_id`), ADD KEY `pages_blocks_meta_language_index` (`language`);

--
-- Indexes for table `pages_meta`
--
ALTER TABLE `pages_meta`
 ADD PRIMARY KEY (`id`), ADD KEY `pages_meta_page_id_index` (`page_id`), ADD KEY `pages_meta_language_index` (`language`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
 ADD PRIMARY KEY (`id`), ADD KEY `photos_gallery_id_index` (`gallery_id`);

--
-- Indexes for table `rel_mod_gallery`
--
ALTER TABLE `rel_mod_gallery`
 ADD PRIMARY KEY (`id`), ADD KEY `rel_mod_gallery_module_index` (`module`), ADD KEY `unit_id` (`module`);

--
-- Indexes for table `seo`
--
ALTER TABLE `seo`
 ADD PRIMARY KEY (`id`), ADD KEY `unit_id` (`module`), ADD KEY `seo_module_index` (`module`), ADD KEY `seo_unit_id_index` (`unit_id`), ADD KEY `seo_url_index` (`url`(255));

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
 ADD UNIQUE KEY `sessions_id_unique` (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `storages`
--
ALTER TABLE `storages`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploads`
--
ALTER TABLE `uploads`
 ADD PRIMARY KEY (`id`), ADD KEY `uploads_mime1_index` (`mime1`), ADD KEY `uploads_mime2_index` (`mime2`), ADD KEY `uploads_module_index` (`module`), ADD KEY `uploads_unit_id_index` (`unit_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indexes for table `videos`
--
ALTER TABLE `videos`
 ADD PRIMARY KEY (`id`), ADD KEY `videos_module_index` (`module`), ADD KEY `videos_unit_id_index` (`unit_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `actions`
--
ALTER TABLE `actions`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `dictionary`
--
ALTER TABLE `dictionary`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `dictionary_fields_values`
--
ALTER TABLE `dictionary_fields_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=217;
--
-- AUTO_INCREMENT for table `dictionary_values`
--
ALTER TABLE `dictionary_values`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT for table `dictionary_values_meta`
--
ALTER TABLE `dictionary_values_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `modules`
--
ALTER TABLE `modules`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `news_meta`
--
ALTER TABLE `news_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages_blocks`
--
ALTER TABLE `pages_blocks`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages_blocks_meta`
--
ALTER TABLE `pages_blocks_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pages_meta`
--
ALTER TABLE `pages_meta`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `photos`
--
ALTER TABLE `photos`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `rel_mod_gallery`
--
ALTER TABLE `rel_mod_gallery`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `seo`
--
ALTER TABLE `seo`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `storages`
--
ALTER TABLE `storages`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `uploads`
--
ALTER TABLE `uploads`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `videos`
--
ALTER TABLE `videos`
MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
